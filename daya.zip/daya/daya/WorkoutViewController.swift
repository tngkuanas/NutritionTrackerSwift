//
//  WorkoutViewController.swift
//  daya
//
//  Created by STDC_39 on 12/08/2024.
//

import UIKit

class WorkoutViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var tableView: UITableView!
    var tableData: [WorkoutList] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableData = WorkoutList.sampleExerciseData()
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let workoutCell =
        tableView.dequeueReusableCell(withIdentifier: "workoutList", for: indexPath) as! WorkoutCell
        let workoutList = tableData[indexPath.row]
        workoutCell.nameLabel.text = workoutList.name
        workoutCell.kcalLabel.text = workoutList.kcal
        
        if indexPath.row == 1 {
            let addButton = workoutList.button
            workoutCell.AddButton.layer.cornerRadius = addButton.layer.cornerRadius
            workoutCell.AddButton.setImage(UIImage(named: "yourImageName"), for: .normal)
            workoutCell.AddButton.tintColor = addButton.tintColor
            workoutCell.AddButton.clipsToBounds = true
        } else {
            workoutCell.AddButton.isHidden = true
        }
        return workoutCell
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tableData.count
    }
    
    // MARK: - Navigation
    /*
     override func prepare(for segue: UIStoryboardSegue, sender: Any?){
         guard let durationViewController = segue.destination as? DurationViewController, let selectedCell = sender as? ExerciseCell, let indexPath = tableView.indexPath(for: selectedCell) else {
             fatalError("Could not get indexPath")
         }
         let selectedExList = tableData[indexPath.row]
         durationViewController.selectedExList = selectedExList
     }
     */

}

