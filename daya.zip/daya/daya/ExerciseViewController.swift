//
//  ExerciseViewController.swift
//  daya
//
//  Created by STDC_39 on 08/08/2024.
//

import UIKit

class ExerciseViewController: UIViewController {
    // @IBOutlet var myImageView: UIImageView!
     @IBOutlet var homepageButton1: UIButton!
    @IBOutlet var homepageButton2: UIButton!
    @IBOutlet var homepageButton3: UIButton!
    @IBOutlet var homepageButton4: UIButton!

     
     override func viewDidLoad() {
         super.viewDidLoad()
         homepageButton1.editButton(opacity: 1)
         homepageButton2.editButton(opacity: 1)
         homepageButton3.editButton(opacity: 1)
         homepageButton4.editButton(opacity: 1)

   //      homepageButton2.editHomeButton(withText: "", opacity: 0)
     //    homepageButton3.editHomeButton(withText: "", opacity: 0)
     }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIButton {
    func editButton(opacity: CGFloat = 1.0) {
        self.layoutIfNeeded()
        self.layer.cornerRadius = self.frame.height / 7
        self.clipsToBounds = true
        self.alpha = opacity // Set the opacity of the UIButton
    }
}
