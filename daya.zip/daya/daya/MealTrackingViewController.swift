import UIKit

class MealTrackingViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, LogFoodViewControllerDelegate {

    @IBOutlet var tableView: UITableView!
    @IBOutlet var roundButton: UIButton!
    var tableData: [Food] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableData = Food.sampleTeamData()

        // Round button edges
        roundButton.layer.cornerRadius = 20
        roundButton.clipsToBounds = true
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let foodCell =
            tableView.dequeueReusableCell(withIdentifier: "FoodMember", for: indexPath) as! FoodCell
        let foodMember = tableData[indexPath.row]
        foodCell.photoImageView.image = foodMember.photo
        foodCell.nameLabel.text = foodMember.name
        return foodCell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Remove the food item from the data source
            tableData.remove(at: indexPath.row)
            
            // Delete the corresponding row from the table view
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.reloadData()

            
        }
    }


    // MARK: - LogFoodViewControllerDelegate
    func didAddFood(_ food: Food) {
        tableData.append(food)
        tableView.reloadData()
    }

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let logFoodVC = segue.destination as? LogFoodViewController {
            logFoodVC.delegate = self
        } else if let foodViewController = segue.destination as? FoodViewController,
                  let selectedCell = sender as? FoodCell,
                  let indexPath = tableView.indexPath(for: selectedCell) {
            let selectedFood = tableData[indexPath.row]
            foodViewController.selectedFood = selectedFood
        }
    }
}
