//
//  ExerciseCell.swift
//  test_daya
//
//  Created by STDC_48 on 08/08/2024.
//

import UIKit

class ExerciseCell: UITableViewCell {
    
    @IBOutlet var nameLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
