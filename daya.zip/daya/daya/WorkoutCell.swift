//
//  WorkoutCell.swift
//  daya
//
//  Created by STDC_39 on 12/08/2024.
//

import UIKit

class WorkoutCell: UITableViewCell {
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var kcalLabel: UILabel!
    @IBOutlet var AddButton: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
