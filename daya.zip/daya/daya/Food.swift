//
//  Team Member.swift
//  About My Team
//
//  Created by stdc_25 on 07/08/2024.
//

import UIKit

struct Food{
    let photo : UIImage?
    let name : String
    let protein: String
    let carbohydrate : String
    let fat : String
    let calorie : String
}

extension Food{
    static func sampleTeamData() -> [Food]{
        let photo1 = UIImage(named: "Bread")
        let photo2 = UIImage(named: "Chicken")
        let photo3 = UIImage(named: "Meat")
        let food1 = Food(photo: photo1, name: "Bread", protein: "PROTEIN 10g", carbohydrate: "CARB 100g", fat: "FAT 12g",calorie: "1000kcal")
        let food2 = Food(photo: photo2, name: "Chicken", protein: "PROTEIN 10g", carbohydrate: "CARB 100g", fat: "FAT 12g",calorie: "1000kcal")
        let food3 = Food(photo: photo3, name: "Meat", protein: "PROTEIN 10g", carbohydrate: "CARB 100g", fat: "FAT 12g",calorie: "1000kcal")
        
        return[food1,food2,food3]

    }
}
