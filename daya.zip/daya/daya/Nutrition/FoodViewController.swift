import UIKit

class FoodViewController: UIViewController {

    @IBOutlet var myImageView: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var proteinLabel: UILabel!
    @IBOutlet var carbohydrateLabel: UILabel!
    @IBOutlet var fatLabel: UILabel!
    @IBOutlet var calorieLabel: UILabel!
    @IBOutlet var roundImageView: UIImageView!  // Added Outlet for the Round Image View
    
    var selectedFood: Food?

    override func viewDidLoad() {
        super.viewDidLoad()
        myImageView.image = selectedFood?.photo
        nameLabel.text = selectedFood?.name
        proteinLabel.text = selectedFood?.protein
        carbohydrateLabel.text = selectedFood?.carbohydrate
        fatLabel.text = selectedFood?.fat
        calorieLabel.text = selectedFood?.calorie
        
        // Configure the round image view
        roundImageView.clipToCircle()  // Custom function to style the image view
    }
}

extension UIImageView {
    func clipToCircle() {
        self.layoutIfNeeded()
        self.layer.cornerRadius = self.frame.height / 2
        self.clipsToBounds = true
    }
}
