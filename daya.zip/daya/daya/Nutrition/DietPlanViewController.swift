import UIKit

class DietPlanViewController: UIViewController {  // Changed to UIViewController

    @IBOutlet var roundedButton: UIButton!  // Added Outlet for the Button

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Round the button's edges
        roundedButton.layer.cornerRadius = 10  // Adjust the radius as needed
        roundedButton.clipsToBounds = true
    }
}
