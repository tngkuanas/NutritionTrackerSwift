//
//  LogFoodViewController.swift
//  daya
//
//  Created by STDC_39 on 11/08/2024.
//

import UIKit

protocol LogFoodViewControllerDelegate: AnyObject {
    func didAddFood(_ food: Food)
}

class LogFoodViewController: UIViewController {
    
    
    @IBOutlet var submitButton: UIButton!
    @IBOutlet var foodName: UITextField!
    @IBOutlet var foodProteins: UITextField!
    @IBOutlet var foodFats: UITextField!
    @IBOutlet var foodCarbs: UITextField!
    @IBOutlet var foodCalories: UITextField!

    weak var delegate: LogFoodViewControllerDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Adding target to submitButton to dismiss the view controller when tapped
        submitButton.addTarget(self, action: #selector(dismissViewController), for: .touchUpInside)
    }
    
    @objc func dismissViewController() {
        // Use the foodName to get the corresponding image from assets
        let foodImage = UIImage(named: foodName.text ?? "")

        // Create a Food instance with the data from text fields
        let food = Food(photo: foodImage,
                        name: foodName.text ?? "",
                        protein: foodProteins.text ?? "",
                        carbohydrate: foodCarbs.text ?? "",
                        fat: foodFats.text ?? "",
                        calorie: foodCalories.text ?? "")
        
        delegate?.didAddFood(food)
        dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
