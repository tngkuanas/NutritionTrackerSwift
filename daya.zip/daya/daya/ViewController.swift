import UIKit
import CoreImage

class ViewController: UIViewController {
    
    @IBOutlet var myButton1: UIButton!
    @IBOutlet var myButton2: UIButton!
    @IBOutlet var myButton3: UIButton!
    
    @IBOutlet var homepageButton: UIImageView!
    @IBOutlet var homepageButton2: UIImageView!
    @IBOutlet var homepageButton3: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        myButton1.editImageButton(withText: "HELLO", opacity: 0.5)
        myButton2.editImageButton(withText: "HELLLOOOOOOO", opacity: 0.5)
        myButton3.editImageButton(withText: "I", opacity: 0.5)
    }
}

extension UIButton {
    func editImageButton(withText text: String, opacity: CGFloat = 1.0) {
        self.layoutIfNeeded()
        self.layer.borderColor = UIColor.systemRed.cgColor
        self.layer.cornerRadius = self.frame.height / 10
        self.clipsToBounds = true

        if let originalImage = self.image(for: .normal) {
            // Apply black and white filter
            let blackAndWhiteImage = applyBlackAndWhiteFilter(to: originalImage)
            
            // Adjust opacity and add text overlay
            let imageWithText = addTextOverlay(to: blackAndWhiteImage, text: text, opacity: opacity)
            self.setImage(imageWithText, for: .normal)
        }
    }
    
    private func applyBlackAndWhiteFilter(to image: UIImage) -> UIImage? {
        guard let ciImage = CIImage(image: image) else { return nil }
        
        // Apply a black-and-white filter using a grayscale conversion
        let filter = CIFilter(name: "CIPhotoEffectNoir") // Noir is a grayscale filter
        filter?.setValue(ciImage, forKey: kCIInputImageKey)
        
        guard let outputCIImage = filter?.outputImage else { return nil }
        
        let context = CIContext()
        let rect = CGRect(origin: .zero, size: image.size)
        
        guard let cgImage = context.createCGImage(outputCIImage, from: rect) else { return nil }
        
        return UIImage(cgImage: cgImage)
    }
    
    private func addTextOverlay(to image: UIImage?, text: String, opacity: CGFloat) -> UIImage? {
        guard let image = image else { return nil }
        
        let textColor = UIColor.white // Changed to white for better contrast
        let textFont = UIFont.boldSystemFont(ofSize: 30) // Adjusted font size for better visibility
        let textAttributes: [NSAttributedString.Key: Any] = [
            .font: textFont,
            .foregroundColor: textColor
        ]
        
        let imageSize = image.size
        UIGraphicsBeginImageContextWithOptions(imageSize, false, image.scale)
        
        // Draw the original image
        image.draw(in: CGRect(origin: .zero, size: imageSize))
        
        // Set up text drawing
        let textRect = CGRect(x: 20, y: imageSize.height - 60, width: imageSize.width - 40, height: 60)
        
        // Draw the text with specified attributes
        text.draw(in: textRect, withAttributes: textAttributes)
        
        // Capture the image with text overlay
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        // Apply opacity to the final image
        guard let imageWithText = newImage else { return nil }
        
        UIGraphicsBeginImageContextWithOptions(imageSize, false, image.scale)
        let context = UIGraphicsGetCurrentContext()
        context?.setBlendMode(.normal)
        context?.setAlpha(opacity)
        
        // Draw the image with text and applied opacity
        imageWithText.draw(in: CGRect(origin: .zero, size: imageSize))
        
        let finalImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return finalImage
    }

}
