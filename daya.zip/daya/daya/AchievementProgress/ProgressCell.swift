//
//  ProgressCell.swift
//  daya
//
//  Created by STDC_39 on 09/08/2024.
//

import UIKit

class ProgressCell: UICollectionViewCell {
    
    var cornerRadius: CGFloat = 20

    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var claimButton: UIButton!


    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Apply rounded corners to contentView
           contentView.layer.cornerRadius = cornerRadius
           contentView.layer.masksToBounds = true
           
           // Set masks to bounds to false to avoid the shadow
           // from being clipped to the corner radius
           layer.cornerRadius = cornerRadius
           layer.masksToBounds = false
        // Initialization code
    }

        // Configure the view for the selected state

}
