//
//  File.swift
//  daya
//
//  Created by STDC_39 on 09/08/2024.
//

import UIKit

struct ProgressMembers {
    let photo: UIImage?
    let title: String
    let description: String
    let claimButton: UIButton
    
    
    
}

extension ProgressMembers {
    static func createButton(title: String, color: UIColor) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.setTitleColor(.white, for: .normal)
        
        // Set the background color to transparent
        button.backgroundColor = .clear
        
        // Add a border with the specified color
        button.layer.borderColor = UIColor(red: 186/255, green: 253/255, blue: 78/255, alpha: 1.0).cgColor
        button.layer.borderWidth = 1.0
        
        // Make the corners rounded
        button.layer.cornerRadius = 10 // Adjust the radius as needed
        button.clipsToBounds = true
        
        return button
    }
    
    static func createButton2(title: String, titleColor: UIColor, color: UIColor) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.setTitleColor(titleColor, for: .normal)
        
        // Set the background color to transparent
        button.backgroundColor = UIColor(red: 186/255, green: 253/255, blue: 78/255, alpha: 1.0)
        
        // Make the corners rounded
        button.layer.cornerRadius = 10 // Adjust the radius as needed
        button.clipsToBounds = true
        
        return button
    }
    
    static func sampleTeamData() -> [ProgressMembers] {
        let photo1 = UIImage(named: "1KM")
        let photo2 = UIImage(named: "1000KCAL")
        let photo3 = UIImage(named: "1W")
        
        let progressMembers1 = ProgressMembers(photo: photo1, title: "Starting Line Champion", description: "Complete your first 1KM run", claimButton: createButton2(title: "Claim", titleColor: .black, color: .clear))
        let progressMembers2 = ProgressMembers(photo: photo2, title: "Burn Baby Burn", description: "Burnt your first 1000Kcal", claimButton: createButton(title: "Claim", color: .clear))
        let progressMembers3 = ProgressMembers(photo: photo3, title: "One Week Wonder" , description: "Active for 1 week", claimButton: createButton(title: "Claim", color: .clear))
       
        return [progressMembers1, progressMembers2, progressMembers3]

    }
}
