//
//  CollectionViewController.swift
//  Daya
//
//  Created by STDC_39 on 07/08/2024.
//

import UIKit
import Foundation

class ProgressViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet var button1: UIButton!


    @IBOutlet var collectionView: UICollectionView!
    var imageArray: [ProgressMembers] = []
    var frame = CGFloat(0)


    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        imageArray = ProgressMembers.sampleTeamData()
        button1.editHomeButton(opacity: 1)


        // Do any additional setup after loading the view.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let progressCell = collectionView.dequeueReusableCell(withReuseIdentifier: "progressCell", for: indexPath) as! ProgressCell
        let progressMembers = imageArray[indexPath.row]
        progressCell.photoImageView.image = progressMembers.photo
        progressCell.titleLabel.text = progressMembers.title
        progressCell.descriptionLabel.text = progressMembers.description
        
        // Configure the claim button in the cell
        let claimButton = progressMembers.claimButton
        progressCell.claimButton.setTitle(claimButton.currentTitle, for: .normal)
        progressCell.claimButton.backgroundColor = claimButton.backgroundColor
        progressCell.claimButton.layer.cornerRadius = claimButton.layer.cornerRadius
        progressCell.claimButton.layer.borderColor = claimButton.layer.borderColor
        progressCell.claimButton.layer.borderWidth = claimButton.layer.borderWidth
        progressCell.claimButton.clipsToBounds = true
        
        if indexPath.row == 0 {
              progressCell.claimButton.setTitleColor(.black, for: .normal)
          }
        
        
        
        return progressCell
    }
    
   /* func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
           let selectedImage = imageArray[indexPath.row]
           print("Selected item at index \(indexPath.row)")
           
           let storyboard = UIStoryboard(name: "Main", bundle: nil)
           
           switch indexPath.row {
           case 0:
               print("Navigating to NutritionViewController")
               if let nutritionVC = storyboard.instantiateViewController(withIdentifier: "NutritionViewController") as? ViewController {
                  // nutritionVC.homeImage = selectedImage
                   navigationController?.pushViewController(nutritionVC, animated: true)
               }
           case 1:
               print("Navigating to ActivityViewController")
               if let activityVC = storyboard.instantiateViewController(withIdentifier: "ActivityViewController") as? ActivityViewController {
                   //activityVC.homeImage = selectedImage
                   navigationController?.pushViewController(activityVC, animated: true)
               }
         /*  case 2:
               print("Navigating to AchievementViewController")
               if let achievementVC = storyboard.instantiateViewController(withIdentifier: "AchievementViewController") as? AchievementViewController {
                   achievementVC.homeImage = selectedImage
                   navigationController?.pushViewController(achievementVC, animated: true)
               } */
           default:
               print("Navigating to DefaultViewController")
               if let defaultVC = storyboard.instantiateViewController(withIdentifier: "DefaultViewController") as? ViewController {
                 //  defaultVC.homeImage = selectedImage
                   navigationController?.pushViewController(defaultVC, animated: true)
               }
           }
       } */


}

extension UIButton {
    func editHomeButton(opacity: CGFloat = 1.0) {
        self.layoutIfNeeded()
        self.layer.borderColor = UIColor(red: 186/255, green: 253/255, blue: 78/255, alpha: 1.0).cgColor
        self.layer.borderWidth = 1.0 // You can adjust the border width as needed
        self.layer.cornerRadius = self.frame.height / 10
        self.clipsToBounds = true
        self.alpha = opacity // Set the opacity of the UIImageView
    }
}
