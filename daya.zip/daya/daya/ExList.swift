//
//  ExList.swift
//  test_daya
//
//  Created by STDC_48 on 08/08/2024.
//

import UIKit

struct ExList {
    
    let name: String
}

extension ExList{
    static func sampleExerciseData() -> [ExList]{
    
        let exList1 = ExList(name: "Walking")
        let exList2 = ExList(name: "Cycling")
        let exList3 = ExList(name: "Jogging")
        let exList4 = ExList(name: "Dancing")
        return [exList1, exList2, exList3, exList4]
    }
}

