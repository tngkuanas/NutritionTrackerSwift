//
//  AdsViewController.swift
//  daya
//
//  Created by STDC_40 on 12/08/2024.
//

import UIKit

class AdsViewController: UIViewController {
    
    @IBOutlet var skipButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Adding target to submitButton to dismiss the view controller when tapped
        skipButton.addTarget(self, action: #selector(dismissViewController), for: .touchUpInside)
        // Do any additional setup after loading the view.
    }
    
    @objc func dismissViewController() {

        dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
