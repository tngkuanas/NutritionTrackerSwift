//
//  WorkoutList.swift
//  daya
//
//  Created by STDC_39 on 12/08/2024.
//


import UIKit

class WorkoutListViewController: UITableViewController {
    
    let workoutList = WorkoutList.sampleExerciseData()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return workoutList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let workout = workoutList[indexPath.row]
        cell.textLabel?.text = "\(workout.name) - \(workout.kcal)"
    
        return cell
    }
    
}

struct WorkoutList {
    
    let name: String
    let kcal: String
    let button: UIButton
}

extension WorkoutList{
    static func createButton(color: UIColor, size: CGFloat) -> UIButton {
        let button = UIButton(type: .system)
        
        // Set the button's image to "plus.circle.fill"
        let image = UIImage(systemName: "plus.circle.fill")
        button.setImage(image, for: .normal)
        
        // Set the image's tint color
        button.tintColor = color
        
        // Ensure the button is circular
        button.layer.cornerRadius = size / 2
        button.clipsToBounds = true
       
        return button
    }

    static func sampleExerciseData() -> [WorkoutList]{
    
        let woList1 = WorkoutList(name: "Walking(100mins)", kcal: "240kcal", button: createButton(color: .systemGreen, size: 10))
        let woList2 = WorkoutList(name: "Add", kcal: "_kcal", button: createButton(color: .systemGreen, size: 10))
        
        return [woList1, woList2]
    }
    
}


