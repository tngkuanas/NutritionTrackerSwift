//
//  LaunchViewController.swift
//  daya
//
//  Created by STDC_39 on 12/08/2024.
//

import UIKit

class LaunchViewController: UIViewController {

    @IBOutlet var launchImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        animateLaunchImage()
    }

    func animateLaunchImage() {
        // Initial setup for the image view
        launchImageView.alpha = 1.0
        launchImageView.transform = CGAffineTransform.identity

        // First, animate the image to expand
        UIView.animate(withDuration: 1.5, // Duration for expansion
                       delay: 0.0, // No delay
                       options: [.curveEaseOut],
                       animations: {
            // Scale up the image
            self.launchImageView.transform = CGAffineTransform(scaleX: 2.0, y: 2.0)
        }, completion: { _ in
            // After expanding, wait for 2 seconds before fading out
            UIView.animate(withDuration: 1.5, // Duration for fade out
                           delay: 2.0, // Wait for 2 seconds before starting fade out
                           options: [.curveEaseOut],
                           animations: {
                // Fade out the image
                self.launchImageView.alpha = 0.0
            }, completion: { _ in
                // After the animation completes, transition to the next screen
                self.transitionToNextScreen()
            })
        })
    }

    func transitionToNextScreen() {
        // Perform the transition to your main screen
        performSegue(withIdentifier: "showMainScreen", sender: self)
    }
}
