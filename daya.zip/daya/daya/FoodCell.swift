//
//  TeamCell.swift
//  About My Team
//
//  Created by stdc_25 on 07/08/2024.
//

import UIKit

class FoodCell: UITableViewCell {
    
    @IBOutlet var photoImageView : UIImageView!
    @IBOutlet var nameLabel : UILabel!
//    @IBOutlet var aboutMeLabel : UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
