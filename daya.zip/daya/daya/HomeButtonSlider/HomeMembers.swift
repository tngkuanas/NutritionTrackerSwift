//
//  TeamMember.swift
//  Daya
//
//  Created by STDC_39 on 07/08/2024.
//

import UIKit

struct HomeImages {
    let photo: UIImage?
    let name: String
    
}

extension HomeImages {
    static func sampleTeamData() -> [HomeImages] {
        let photo1 = UIImage(named: "Nutritions")
        let photo2 = UIImage(named: "Activities")
        let photo3 = UIImage(named: "Achievements")
        let homeImage1 = HomeImages(photo: photo1, name: "NUTRITIONS")
        let homeImage2 = HomeImages(photo: photo2, name: "ACTIVITY")
        let homeImage3 = HomeImages(photo: photo3, name: "ACHIEVEMENTS")
       
        return [homeImage1, homeImage2, homeImage3]

    }
}


