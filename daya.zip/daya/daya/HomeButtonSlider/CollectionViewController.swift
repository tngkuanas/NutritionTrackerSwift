//
//  CollectionViewController.swift
//  Daya
//
//  Created by STDC_39 on 07/08/2024.
//

import UIKit
import Foundation

class CollectionViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet var collectionView: UICollectionView!
    var imageArray: [HomeImages] = []
    var frame = CGFloat(0)


    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        imageArray = HomeImages.sampleTeamData()

        // Do any additional setup after loading the view.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let homeCell = collectionView.dequeueReusableCell(withReuseIdentifier: "homeCell", for: indexPath) as! HomeCell
        let homeImage = imageArray[indexPath.row]
        homeCell.photoImageView.image = homeImage.photo
        homeCell.nameLabel.text = homeImage.name
                return homeCell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
           let selectedImage = imageArray[indexPath.row]
           print("Selected item at index \(indexPath.row)")
           
           let storyboard = UIStoryboard(name: "Main", bundle: nil)
           
           switch indexPath.row {
           case 0:
               print("Navigating to NutritionViewController")
               if let nutritionVC = storyboard.instantiateViewController(withIdentifier: "NutritionViewController") as? ViewController {
                  // nutritionVC.homeImage = selectedImage
                   navigationController?.pushViewController(nutritionVC, animated: true)
               }
           case 1:
               print("Navigating to ActivityViewController")
               if let activityVC = storyboard.instantiateViewController(withIdentifier: "ActivityViewController") as? ActivityViewController {
                   //activityVC.homeImage = selectedImage
                   navigationController?.pushViewController(activityVC, animated: true)
               }
           case 2:
               print("Navigating to AchievementViewController")
               if let achievementVC = storyboard.instantiateViewController(withIdentifier: "ProgressViewController") as? ProgressViewController {
                   // achievementVC.homeImage = selectedImage
                   navigationController?.pushViewController(achievementVC, animated: true)
               }
           default:
               print("Navigating to DefaultViewController")
               if let defaultVC = storyboard.instantiateViewController(withIdentifier: "DefaultViewController") as? ViewController {
                 //  defaultVC.homeImage = selectedImage
                   navigationController?.pushViewController(defaultVC, animated: true)
               }
           }
       }


}

extension UIImageView {
    func editImageView(opacity: CGFloat = 1.0) {
        self.layoutIfNeeded()
        self.layer.borderWidth = 1.0 // You can adjust the border width as needed
        self.layer.cornerRadius = self.frame.height / 10
        self.clipsToBounds = true
        self.alpha = opacity // Set the opacity of the UIImageView
    }
}
