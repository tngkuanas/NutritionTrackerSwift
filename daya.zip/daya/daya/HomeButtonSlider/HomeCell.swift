//
//  TeamCell.swift
//  Daya
//
//  Created by STDC_39 on 07/08/2024.
//

import UIKit

class HomeCell: UICollectionViewCell {
    
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var nameLabel: UILabel!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        photoImageView.editImageView()
        // Initialization code
    }

     private func editImageView(opacity: CGFloat = 1.0) {
            self.layoutIfNeeded()
            self.layer.borderColor = UIColor.systemRed.cgColor
            self.layer.borderWidth = 1.0 // You can adjust the border width as needed
            self.layer.cornerRadius = self.frame.height / 10
            self.clipsToBounds = true
            self.alpha = opacity // Set the opacity of the UIImageView
        }

        // Configure the view for the selected state

}
