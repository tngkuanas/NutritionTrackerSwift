//
//  ProfileViewController.swift
//  daya
//
//  Created by STDC_39 on 12/08/2024.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet var button1: UIButton!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        button1.editProfileButton(opacity: 1)

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIButton {
    func editProfileButton(opacity: CGFloat = 1.0) {
        self.layoutIfNeeded()
       self.layer.borderColor = UIColor(red: 186/255, green: 253/255, blue: 78/255, alpha: 1.0).cgColor
    self.layer.borderWidth = 1.0 // You can adjust the border width as needed
        self.layer.cornerRadius = self.frame.height / 12

        self.clipsToBounds = true
        self.alpha = opacity // Set the opacity of the UIImageView
    }
}
